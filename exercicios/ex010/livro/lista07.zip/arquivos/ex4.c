#include <stdio.h>

/*
 * Exercício 4 - Arquivos
 * Faça um programa que receba do usuário um arquivo texto, crie outro arquivo contendo o texto do arquivo de entrada, mas com as vogais substituídas por ‘*’.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
