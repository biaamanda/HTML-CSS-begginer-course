#include <stdio.h>

/*
 * Exercício 5 - Arquivos
 * Faça um programa que receba dois arquivos do usuário e crie um terceiro arquivo com o conteúdo dos dois arquivos recebidos juntos (o conteúdo do primeiro seguido do conteúdo do segundo).
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
