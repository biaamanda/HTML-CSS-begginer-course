#include <stdio.h>
#include <stdlib.h>

/*
 * Exercício 6 - Arquivos
 * Crie um programa que receba como entrada o número de alunos de uma disciplina. Aloque dinamicamente dois vetores para armazenar as informações a respeito desses alunos. O primeiro vetor contém o nome dos alunos e o segundo contém suas notas finais. Crie um arquivo que armazene, a cada linha, o nome do aluno e sua nota final. Use nomes com no máximo 40 caracteres. Se o nome não contém 40 caracteres, complete com espaço em branco.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
