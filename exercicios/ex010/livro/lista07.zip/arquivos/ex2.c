#include <stdio.h>

/*
 * Exercício 2 - Arquivos
 * Faça um programa que receba do usuário um arquivo texto e mostra na tela quantas linhas esse arquivo possui.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
