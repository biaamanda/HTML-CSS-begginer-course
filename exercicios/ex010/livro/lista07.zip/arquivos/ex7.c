#include <stdio.h>
#include <stdlib.h>

/*
 * Exercício 7 - Arquivos
 * Faça um programa gerenciar uma agenda de contatos. Para cada contato armazene o nome, o telefone e o aniversário (dia e mês). O programa deve permitir:
  a. inserir contato
  b. remover contato
  c. pesquisar um contato pelo nome
  d. listar todos os contatos
  e. listar os contatos cujo nome inicia com uma dada letra
  f. imprimir os aniversariantes do mês.
Sempre que o programa for encerrado, os contatos devem ser armazenados em um arquivo. Quando o programa iniciar, os contatos devem ser inicializados com os dados contidos neste arquivo.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
