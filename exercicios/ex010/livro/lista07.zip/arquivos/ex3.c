#include <stdio.h>

/*
 * Exercício 3 - Arquivos
 * Faça um programa que receba do usuário um arquivo texto e um caractere e mostre na tela quantas vezes aquele caractere ocorre dentro do arquivo.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
