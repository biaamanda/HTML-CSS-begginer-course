#include <stdio.h>

/*
 * Exercício 4 - Ponteiros
 * Escreva uma função que receba um array de inteiros V e os endereços de duas variáveis inteiras, min e max, e armazene nessas variáveis o valor mínimo e máximo do array.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
