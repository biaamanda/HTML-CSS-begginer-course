#include <stdio.h>
#include <stdlib.h>

/*
 * Exercício 6 - Ponteiros
 * Implemente um programa que permita a entrada de valores de um array cujo tamanho máximo é definido pela constante MAX. A quantidade de valores armazenado no vetor será definida pelo usuário (quando digitar -100, a leitura para). É obrigatório o uso da subrotina ler_vetor, que recebe como parâmetros um ponteiro que aponta para o início do vetor e um ponteiro para um valor inteiro que representa o tamanho real do vetor.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
