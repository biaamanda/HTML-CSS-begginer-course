#include <stdio.h>

/*
 * Exercício 1 - Ponteiros
 * Faça um programa que leia dois valores inteiros e chame uma função que receba estes 2 valores de entrada e retorne o maior valor na primeira variável e o menor valor na segunda variável. Escreva o conteúdo das 2 variáveis na tela.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
