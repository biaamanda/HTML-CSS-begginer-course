#include <stdio.h>

/*
 * Exercício 3 - Ponteiros
 * Crie um programa que contenha uma matriz de float contendo 3 linhas e 3 colunas. Imprima o endereço de cada posição dessa matriz.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
