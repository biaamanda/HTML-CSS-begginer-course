#include <stdio.h>

/*
 * Exercício 5 - Ponteiros
 * Implemente um programa que leia dois valores inteiros (A e B). A seguir, troque os seus valores utilizando a subrotina troca_valores. A subrotina deve receber dois ponteiros para inteiros e trocar os seus valores de lugar.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
