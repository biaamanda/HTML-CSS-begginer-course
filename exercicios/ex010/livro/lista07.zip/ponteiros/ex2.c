#include <stdio.h>

/*
 * Exercício 2 - Ponteiros
 * Crie um programa que contenha um array de float contendo 10 elementos. Imprima o endereço de cada posição desse array.
 */

int main() {
    // TODO: implementar o exercício
    return 0;
}
