# Lista 07 - Ponteiros e Arquivos

Este projeto contém os exercícios da Lista 07, organizados em duas categorias:

## Estrutura

```
lista07/
├── ponteiros/
│   ├── ex1.c
│   ├── ...
├── arquivos/
│   ├── ex1.c
│   ├── ...
```

Cada arquivo `.c` contém um esboço básico para implementar o exercício correspondente.

## Como compilar e executar

Para compilar e executar um dos arquivos:

```bash
gcc ponteiros/ex1.c -o ex1
./ex1
```
